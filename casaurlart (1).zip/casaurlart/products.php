<?php
require_once __DIR__ . '/config.php';
$cat = $_GET['cat'] ?? '';
$custom = !empty($_GET['custom']);
$where = "1=1";
$params = [];
if ($cat) { $where .= " AND c.slug=?"; $params[]=$cat; }
if ($custom) { $where .= " AND p.custom_made=1"; }
$sql = "SELECT p.*, c.name as category, c.slug as cslug FROM products p LEFT JOIN categories c ON c.id=p.category_id WHERE $where ORDER BY p.id DESC";
$st = db()->prepare($sql); $st->execute($params);
$rows = $st->fetchAll();
$cats = db()->query("SELECT * FROM categories ORDER BY name")->fetchAll();
$page_title = $custom ? 'Sana Özel Tasarımlar' : 'Koleksiyon';
include __DIR__ . '/includes/header.php';
?>
<section class="section">
  <div class="container">
    <div class="section-head">
      <div>
        <div class="eyebrow"><?=$custom?'Custom Made':'Tüm Ürünler'?></div>
        <h2><?=e($page_title)?></h2>
      </div>
      <div style="display:flex;gap:8px;flex-wrap:wrap" data-testid="category-filters">
        <a class="chip <?=$cat===''?'active':''?>" href="<?=base_url('products.php'.($custom?'?custom=1':''))?>">Hepsi</a>
        <?php foreach($cats as $c): ?>
          <a class="chip <?=$cat===$c['slug']?'active':''?>" href="<?=base_url('products.php?cat='.urlencode($c['slug']).($custom?'&custom=1':''))?>"><?=e($c['name'])?></a>
        <?php endforeach; ?>
      </div>
    </div>
    <?php if(empty($rows)): ?>
      <div class="panel" style="text-align:center;padding:60px">Henüz ürün eklenmemiş. Admin panelden ekleyin.</div>
    <?php else: ?>
    <div class="grid" data-testid="products-grid">
      <?php foreach($rows as $p): ?>
      <article class="card" data-testid="product-card-<?=$p['id']?>">
        <a href="<?=base_url('product.php?id='.$p['id'])?>" class="thumb">
          <?php if($p['custom_made']): ?><span class="badge">Sana Özel</span><?php endif; ?>
          <img src="<?=e(product_image_url($p['image']))?>" alt="<?=e($p['name'])?>" loading="lazy">
        </a>
        <div class="body">
          <span class="cat"><?=e($p['category'] ?? '—')?></span>
          <h3><?=e($p['name'])?></h3>
          <span class="price"><?=money($p['price'])?></span>
        </div>
        <div class="actions">
          <a href="<?=base_url('product.php?id='.$p['id'])?>">İncele</a>
          <a class="wa" href="<?=whatsapp_link('Merhaba, '.$p['name'].' (#'.$p['id'].') hakkında bilgi.')?>" target="_blank"><i class="fa-brands fa-whatsapp"></i></a>
        </div>
      </article>
      <?php endforeach; ?>
    </div>
    <?php endif; ?>
  </div>
</section>
<style>
.section-head .chip{background:#fff;color:var(--ink);text-decoration:none;font-size:.82rem}
.section-head .chip.active{background:var(--ink);color:#fff}
</style>
<?php include __DIR__ . '/includes/footer.php'; ?>
