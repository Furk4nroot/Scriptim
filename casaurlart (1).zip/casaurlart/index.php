<?php
require_once __DIR__ . '/config.php';
$page_title = setting('site_tagline');
$featured = db()->query("SELECT p.*, c.name as category FROM products p LEFT JOIN categories c ON c.id=p.category_id WHERE p.is_featured=1 ORDER BY p.id DESC LIMIT 6")->fetchAll();
include __DIR__ . '/includes/header.php';
?>
<section class="hero">
  <div class="container hero-grid">
    <div>
      <div class="eyebrow">3D · El Yapımı · Sana Özel</div>
      <h1><?=e(setting('hero_title'))?> <em>seninle eşleşir.</em></h1>
      <p style="font-size:1.1rem;max-width:520px;margin-top:18px"><?=e(setting('hero_subtitle'))?></p>
      <div class="hero-cta">
        <a href="<?=base_url('products.php')?>" class="btn" data-testid="hero-shop-btn"><i class="fa-solid fa-arrow-right"></i> Koleksiyonu Gez</a>
        <a href="<?=base_url('products.php?custom=1')?>" class="btn outline" data-testid="hero-custom-btn">Sana Özel Tasarla</a>
        <a href="<?=whatsapp_link('Merhaba casaurlart, özel sipariş için yazıyorum.')?>" target="_blank" rel="noopener" class="btn wa" data-testid="hero-whatsapp-btn"><i class="fa-brands fa-whatsapp"></i> WhatsApp</a>
      </div>
    </div>
    <div class="hero-art">
      <img src="https://images.unsplash.com/photo-1581783898377-1c85bf937427?w=1200&q=80" alt="3D printed vase">
      <div class="hero-meta">
        <span>Geometrik Vazo · PLA+ · 22cm</span>
        <strong>490 ₺</strong>
      </div>
    </div>
  </div>
  <div class="container">
    <div class="feature-row">
      <div class="feature"><i class="fa-solid fa-cube"></i><h4>3D Baskı Teknolojisi</h4><p>FDM ve reçine baskı ile yüksek detay, ev için güvenli malzemeler.</p></div>
      <div class="feature"><i class="fa-solid fa-palette"></i><h4>Renk & Model Seçimi</h4><p>Her parça için onlarca renk, mini–maxi boyut, sınırlı üretim seçenekleri.</p></div>
      <div class="feature"><i class="fa-solid fa-pen-nib"></i><h4>Logo Baskı</h4><p>Kendi logonu, monogramını veya kısa metnini ürüne işliyoruz.</p></div>
      <div class="feature"><i class="fa-solid fa-truck-fast"></i><h4>Hızlı Üretim</h4><p>Sipariş sonrası 3–7 iş günü içerisinde kapına teslim.</p></div>
    </div>
  </div>
</section>

<section class="section" id="koleksiyon">
  <div class="container">
    <div class="section-head">
      <div>
        <div class="eyebrow">Öne Çıkanlar</div>
        <h2>Sezonun en sevilenleri</h2>
      </div>
      <p>Geleneksel formları modern geometriyle yeniden yorumladığımız, evine karakter katacak parçalar.</p>
    </div>
    <div class="grid" data-testid="featured-grid">
      <?php foreach($featured as $p): ?>
      <article class="card" data-testid="product-card-<?=$p['id']?>">
        <a href="<?=base_url('product.php?id='.$p['id'])?>" class="thumb">
          <span class="badge">Yeni</span>
          <img src="<?=e(product_image_url($p['image']))?>" alt="<?=e($p['name'])?>" loading="lazy">
        </a>
        <div class="body">
          <span class="cat"><?=e($p['category'] ?? '—')?></span>
          <h3><?=e($p['name'])?></h3>
          <span class="price"><?=money($p['price'])?></span>
        </div>
        <div class="actions">
          <a href="<?=base_url('product.php?id='.$p['id'])?>" data-testid="card-detail-<?=$p['id']?>">İncele</a>
          <a class="wa" href="<?=whatsapp_link('Merhaba, '.$p['name'].' (ID #'.$p['id'].') hakkında bilgi almak istiyorum.')?>" target="_blank" rel="noopener" data-testid="card-wa-<?=$p['id']?>"><i class="fa-brands fa-whatsapp"></i> Sor</a>
        </div>
      </article>
      <?php endforeach; ?>
    </div>
    <div style="text-align:center;margin-top:50px"><a href="<?=base_url('products.php')?>" class="btn outline">Tüm Koleksiyon →</a></div>
  </div>
</section>

<section class="section" style="background:#0a0a0a;color:#d6cdb8" id="hakkimizda">
  <div class="container" style="display:grid;grid-template-columns:1fr 1fr;gap:60px;align-items:center">
    <div>
      <div class="eyebrow" style="color:#a89c87">Atölye</div>
      <h2 style="color:#fff">El emeği, 3D mühendisliği.</h2>
      <p style="color:#a89c87"><?=e(setting('about'))?></p>
      <a href="<?=base_url('contact.php')?>" class="btn" style="background:#fff;color:#000;border-color:#fff;margin-top:18px">Bize Ulaş</a>
    </div>
    <div style="aspect-ratio:1;border-radius:18px;overflow:hidden">
      <img src="https://images.unsplash.com/photo-1612630741022-b29ea30505ec?w=1000&q=80" alt="3D printer" style="width:100%;height:100%;object-fit:cover">
    </div>
  </div>
</section>

<?php include __DIR__ . '/includes/footer.php'; ?>
