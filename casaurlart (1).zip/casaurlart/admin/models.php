<?php
require_once __DIR__ . '/../config.php'; require_admin();
$page_title = 'Model Yönetimi';
$db = db();
if ($_SERVER['REQUEST_METHOD']==='POST') {
    if(!empty($_POST['delete'])){ $db->prepare("DELETE FROM models WHERE id=?")->execute([(int)$_POST['delete']]); flash('Model silindi.'); header('Location: '.base_url('admin/models.php')); exit; }
    $data=[$_POST['name'],(float)$_POST['extra_price']];
    if(!empty($_POST['id'])){ $data[]=(int)$_POST['id']; $db->prepare("UPDATE models SET name=?,extra_price=? WHERE id=?")->execute($data); flash('Model güncellendi.'); }
    else { $db->prepare("INSERT INTO models(name,extra_price) VALUES(?,?)")->execute($data); flash('Model eklendi.'); }
    header('Location: '.base_url('admin/models.php')); exit;
}
$rows = $db->query("SELECT * FROM models ORDER BY id")->fetchAll();
$edit = null;
if(isset($_GET['edit'])){ $st=$db->prepare("SELECT * FROM models WHERE id=?"); $st->execute([(int)$_GET['edit']]); $edit=$st->fetch(); }
include __DIR__.'/_head.php';
?>
<div class="panel">
  <h2><?=$edit?'Model Düzenle':'Yeni Model Ekle'?></h2>
  <form method="post" data-testid="model-form">
    <?php if($edit): ?><input type="hidden" name="id" value="<?=$edit['id']?>"><?php endif; ?>
    <div class="form-grid">
      <div class="field"><label>Model Adı</label><input class="input" name="name" required value="<?=e($edit['name']??'')?>" data-testid="m-name"></div>
      <div class="field"><label>Ek Fiyat (<?=e(setting('currency'))?>)</label><input class="input" type="number" step="0.01" name="extra_price" value="<?=e($edit['extra_price']??'0')?>"></div>
    </div>
    <div class="btn-row"><button class="btn" data-testid="m-submit"><?=$edit?'Güncelle':'Ekle'?></button>
    <?php if($edit): ?><a class="btn secondary" href="<?=base_url('admin/models.php')?>">İptal</a><?php endif; ?></div>
  </form>
</div>
<div class="panel">
  <h2>Modeller</h2>
  <table><thead><tr><th>Ad</th><th>Ek Fiyat</th><th></th></tr></thead><tbody>
  <?php foreach($rows as $r): ?>
    <tr><td><strong><?=e($r['name'])?></strong></td><td><?=money($r['extra_price'])?></td>
      <td><a class="btn btn-sm secondary" href="?edit=<?=$r['id']?>">Düzenle</a>
        <form method="post" style="display:inline" onsubmit="return confirm('Silinsin mi?')"><input type="hidden" name="delete" value="<?=$r['id']?>"><button class="btn btn-sm danger">Sil</button></form>
      </td></tr>
  <?php endforeach; ?>
  </tbody></table>
</div>
<?php include __DIR__.'/_foot.php'; ?>
