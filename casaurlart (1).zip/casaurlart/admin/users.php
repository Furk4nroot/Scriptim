<?php
require_once __DIR__ . '/../config.php'; require_admin();
$page_title = 'Yöneticiler';
$db = db();
if ($_SERVER['REQUEST_METHOD']==='POST') {
    if(!empty($_POST['delete'])){
        if((int)$_POST['delete'] === (int)$_SESSION['admin_id']){ flash('Kendinizi silemezsiniz.'); }
        else { $db->prepare("DELETE FROM admins WHERE id=?")->execute([(int)$_POST['delete']]); flash('Kullanıcı silindi.'); }
        header('Location: '.base_url('admin/users.php')); exit;
    }
    $u=trim($_POST['username']??''); $p=$_POST['password']??'';
    if(!empty($_POST['id'])){
        if($p!==''){ $db->prepare("UPDATE admins SET username=?,password=? WHERE id=?")->execute([$u,password_hash($p,PASSWORD_DEFAULT),(int)$_POST['id']]); }
        else { $db->prepare("UPDATE admins SET username=? WHERE id=?")->execute([$u,(int)$_POST['id']]); }
        flash('Güncellendi.');
    } else {
        if(strlen($p)<3){ flash('Şifre çok kısa.'); }
        else { try{ $db->prepare("INSERT INTO admins(username,password) VALUES(?,?)")->execute([$u,password_hash($p,PASSWORD_DEFAULT)]); flash('Yönetici eklendi.'); }catch(Exception $ex){ flash('Bu kullanıcı adı zaten var.'); } }
    }
    header('Location: '.base_url('admin/users.php')); exit;
}
$rows = $db->query("SELECT id,username,created_at FROM admins ORDER BY id")->fetchAll();
$edit=null;
if(isset($_GET['edit'])){ $st=$db->prepare("SELECT id,username FROM admins WHERE id=?"); $st->execute([(int)$_GET['edit']]); $edit=$st->fetch(); }
include __DIR__.'/_head.php';
?>
<div class="panel">
<h2><?=$edit?'Yöneticiyi Düzenle':'Yeni Yönetici Ekle'?></h2>
<form method="post" data-testid="user-form">
  <?php if($edit): ?><input type="hidden" name="id" value="<?=$edit['id']?>"><?php endif; ?>
  <div class="form-grid">
    <div class="field"><label>Kullanıcı Adı</label><input class="input" name="username" required value="<?=e($edit['username']??'')?>"></div>
    <div class="field"><label>Şifre <?=$edit?'(değiştirmek istemiyorsan boş bırak)':''?></label><input class="input" type="password" name="password" <?=$edit?'':'required'?>></div>
  </div>
  <div class="btn-row"><button class="btn"><?=$edit?'Güncelle':'Ekle'?></button>
  <?php if($edit): ?><a class="btn secondary" href="<?=base_url('admin/users.php')?>">İptal</a><?php endif; ?></div>
</form>
</div>
<div class="panel">
<h2>Yöneticiler</h2>
<table><thead><tr><th>Kullanıcı</th><th>Oluşturma</th><th></th></tr></thead><tbody>
<?php foreach($rows as $r): ?>
<tr><td><strong><?=e($r['username'])?></strong> <?=$r['id']==$_SESSION['admin_id']?'<span class="tag green">Sen</span>':''?></td>
<td class="muted small"><?=e($r['created_at'])?></td>
<td><a class="btn btn-sm secondary" href="?edit=<?=$r['id']?>">Düzenle</a>
<?php if($r['id']!=$_SESSION['admin_id']): ?>
<form method="post" style="display:inline" onsubmit="return confirm('Silinsin mi?')"><input type="hidden" name="delete" value="<?=$r['id']?>"><button class="btn btn-sm danger">Sil</button></form>
<?php endif; ?>
</td></tr>
<?php endforeach; ?>
</tbody></table>
</div>
<?php include __DIR__.'/_foot.php'; ?>
