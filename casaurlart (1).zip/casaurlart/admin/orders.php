<?php
require_once __DIR__ . '/../config.php'; require_admin();
$page_title = 'Siparişler';
$db = db();
if ($_SERVER['REQUEST_METHOD']==='POST' && !empty($_POST['status']) && !empty($_POST['id'])) {
    $db->prepare("UPDATE orders SET status=? WHERE id=?")->execute([$_POST['status'],(int)$_POST['id']]);
    flash('Durum güncellendi.'); header('Location: '.base_url('admin/orders.php')); exit;
}
$rows = $db->query("SELECT * FROM orders ORDER BY id DESC")->fetchAll();
include __DIR__.'/_head.php';
?>
<div class="panel">
<h2>Tüm Siparişler</h2>
<table data-testid="orders-table"><thead><tr><th>#</th><th>Müşteri</th><th>Ürün</th><th>Renk/Model</th><th>Logo</th><th>Tutar</th><th>Yöntem</th><th>Durum</th><th>Tarih</th><th></th></tr></thead><tbody>
<?php foreach($rows as $o): ?>
<tr>
<td>#<?=$o['id']?></td>
<td><strong><?=e($o['customer_name'])?></strong><br><span class="muted small"><?=e($o['customer_phone'])?> · <?=e($o['customer_email'])?></span><br><span class="muted small"><?=e($o['address'])?></span></td>
<td><?=e($o['product_name'])?></td>
<td><?=e($o['color']?:'—')?> / <?=e($o['model']?:'—')?><?php if($o['custom_notes']): ?><br><span class="muted small"><?=e($o['custom_notes'])?></span><?php endif; ?></td>
<td><?=e($o['custom_logo']?:'—')?></td>
<td><strong><?=money($o['total_price'])?></strong></td>
<td><?=e($o['payment_method'])?></td>
<td>
  <form method="post" style="display:flex;gap:6px">
    <input type="hidden" name="id" value="<?=$o['id']?>">
    <select name="status" class="input" style="padding:6px 10px;font-size:.8rem">
      <?php foreach(['pending','confirmed','shipped','delivered','cancelled'] as $s): ?>
        <option value="<?=$s?>" <?=$o['status']==$s?'selected':''?>><?=$s?></option>
      <?php endforeach; ?>
    </select>
    <button class="btn btn-sm">↻</button>
  </form>
</td>
<td class="muted small"><?=e($o['created_at'])?></td>
<td><a class="btn btn-sm wa" href="<?=whatsapp_link('Merhaba '.$o['customer_name'].', sipariş #'.$o['id'].' hakkında.')?>" target="_blank"><i class="fa-brands fa-whatsapp"></i></a></td>
</tr>
<?php endforeach; ?>
<?php if(empty($rows)): ?><tr><td colspan="10" style="text-align:center;color:var(--muted);padding:40px">Henüz sipariş yok.</td></tr><?php endif; ?>
</tbody></table>
</div>
<?php include __DIR__.'/_foot.php'; ?>
