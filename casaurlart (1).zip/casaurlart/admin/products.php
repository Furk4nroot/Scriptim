<?php
require_once __DIR__ . '/../config.php'; require_admin();
$page_title = 'Ürün Yönetimi';
$db = db();
$edit = null;
if (isset($_GET['edit'])) {
    $st=$db->prepare("SELECT * FROM products WHERE id=?"); $st->execute([(int)$_GET['edit']]); $edit=$st->fetch();
}
if ($_SERVER['REQUEST_METHOD']==='POST') {
    if (!empty($_POST['delete'])) {
        $st=$db->prepare("DELETE FROM products WHERE id=?"); $st->execute([(int)$_POST['delete']]);
        flash('Ürün silindi.'); header('Location: '.base_url('admin/products.php')); exit;
    }
    $imgName = $edit['image'] ?? '';
    if (!empty($_FILES['image']['tmp_name'])) {
        $ext = strtolower(pathinfo($_FILES['image']['name'], PATHINFO_EXTENSION));
        $imgName = 'p_'.time().'_'.bin2hex(random_bytes(3)).'.'.$ext;
        move_uploaded_file($_FILES['image']['tmp_name'], UPLOAD_DIR.'/'.$imgName);
    }
    $data = [
        $_POST['name'] ?? '', $_POST['description'] ?? '', (float)($_POST['price'] ?? 0),
        (int)($_POST['category_id'] ?? 0) ?: null,
        $imgName,
        $_POST['height'] ?? '', $_POST['width'] ?? '', $_POST['depth'] ?? '',
        $_POST['weight'] ?? '', $_POST['material'] ?? '',
        !empty($_POST['logo_included']) ? 1 : 0,
        !empty($_POST['custom_made']) ? 1 : 0,
        (float)($_POST['custom_extra_price'] ?? 0),
        (int)($_POST['stock'] ?? 99),
        !empty($_POST['is_featured']) ? 1 : 0,
    ];
    if (!empty($_POST['id'])) {
        $data[] = (int)$_POST['id'];
        $sql = "UPDATE products SET name=?,description=?,price=?,category_id=?,image=?,height=?,width=?,depth=?,weight=?,material=?,logo_included=?,custom_made=?,custom_extra_price=?,stock=?,is_featured=? WHERE id=?";
        $db->prepare($sql)->execute($data);
        flash('Ürün güncellendi.');
    } else {
        $sql = "INSERT INTO products(name,description,price,category_id,image,height,width,depth,weight,material,logo_included,custom_made,custom_extra_price,stock,is_featured) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)";
        $db->prepare($sql)->execute($data);
        flash('Ürün eklendi.');
    }
    header('Location: '.base_url('admin/products.php')); exit;
}
$rows = $db->query("SELECT p.*, c.name as cat FROM products p LEFT JOIN categories c ON c.id=p.category_id ORDER BY p.id DESC")->fetchAll();
$cats = $db->query("SELECT * FROM categories ORDER BY name")->fetchAll();
include __DIR__.'/_head.php';
?>
<div class="panel">
  <h2><?=$edit?'Ürünü Düzenle':'Yeni Ürün Ekle'?></h2>
  <form method="post" enctype="multipart/form-data" data-testid="product-form">
    <?php if($edit): ?><input type="hidden" name="id" value="<?=$edit['id']?>"><?php endif; ?>
    <div class="form-grid">
      <div class="field full"><label>Ürün Adı</label><input class="input" name="name" required value="<?=e($edit['name']??'')?>" data-testid="p-name"></div>
      <div class="field full"><label>Açıklama</label><textarea class="input" name="description" rows="3"><?=e($edit['description']??'')?></textarea></div>
      <div class="field"><label>Fiyat (<?=e(setting('currency'))?>)</label><input class="input" type="number" step="0.01" name="price" required value="<?=e($edit['price']??'')?>" data-testid="p-price"></div>
      <div class="field"><label>Kategori</label>
        <select class="input" name="category_id">
          <option value="">— Seçiniz —</option>
          <?php foreach($cats as $c): ?>
            <option value="<?=$c['id']?>" <?=($edit['category_id']??0)==$c['id']?'selected':''?>><?=e($c['name'])?></option>
          <?php endforeach; ?>
        </select>
      </div>
      <div class="field"><label>Boy</label><input class="input" name="height" value="<?=e($edit['height']??'')?>" placeholder="örn 22 cm"></div>
      <div class="field"><label>En</label><input class="input" name="width" value="<?=e($edit['width']??'')?>" placeholder="örn 12 cm"></div>
      <div class="field"><label>Genişlik / Derinlik</label><input class="input" name="depth" value="<?=e($edit['depth']??'')?>"></div>
      <div class="field"><label>Gramaj</label><input class="input" name="weight" value="<?=e($edit['weight']??'')?>" placeholder="örn 310 gr"></div>
      <div class="field full"><label>Materyal</label><input class="input" name="material" value="<?=e($edit['material']??'')?>" placeholder="örn PLA+ Biyo Plastik"></div>
      <div class="field"><label>Custom Made Ek Fiyatı</label><input class="input" type="number" step="0.01" name="custom_extra_price" value="<?=e($edit['custom_extra_price']??'0')?>"></div>
      <div class="field"><label>Stok</label><input class="input" type="number" name="stock" value="<?=e($edit['stock']??'99')?>"></div>
      <div class="field full"><label>Ürün Görseli</label><input class="input" type="file" name="image" accept="image/*" data-testid="p-image">
        <?php if(!empty($edit['image'])): ?><img src="<?=e(product_image_url($edit['image']))?>" style="height:80px;border-radius:8px;margin-top:8px"><?php endif; ?>
      </div>
      <div class="field" style="display:flex;align-items:center;gap:10px"><input type="checkbox" name="custom_made" value="1" <?=(($edit['custom_made']??1))?'checked':''?> id="cm"><label for="cm" style="margin:0">Custom Made Aktif</label></div>
      <div class="field" style="display:flex;align-items:center;gap:10px"><input type="checkbox" name="logo_included" value="1" <?=(!empty($edit['logo_included']))?'checked':''?> id="li"><label for="li" style="margin:0">Logo Baskı Dahil</label></div>
      <div class="field" style="display:flex;align-items:center;gap:10px"><input type="checkbox" name="is_featured" value="1" <?=(!empty($edit['is_featured']))?'checked':''?> id="fe"><label for="fe" style="margin:0">Öne Çıkar</label></div>
    </div>
    <div class="btn-row">
      <button class="btn" type="submit" data-testid="p-submit"><?=$edit?'Güncelle':'Ekle'?></button>
      <?php if($edit): ?><a class="btn secondary" href="<?=base_url('admin/products.php')?>">İptal</a><?php endif; ?>
    </div>
  </form>
</div>

<div class="panel">
  <h2>Tüm Ürünler</h2>
  <table data-testid="products-table">
    <thead><tr><th></th><th>Ad</th><th>Kategori</th><th>Fiyat</th><th>Stok</th><th>Özel</th><th></th></tr></thead>
    <tbody>
    <?php foreach($rows as $r): ?>
      <tr>
        <td><img src="<?=e(product_image_url($r['image']))?>" class="tbl-img"></td>
        <td><strong><?=e($r['name'])?></strong><br><span class="muted small">#<?=$r['id']?></span></td>
        <td><?=e($r['cat']??'—')?></td>
        <td><?=money($r['price'])?></td>
        <td><?=$r['stock']?></td>
        <td><?=$r['custom_made']?'<span class="tag green">Var</span>':'—'?><?=$r['is_featured']?' <span class="tag">⭐</span>':''?></td>
        <td>
          <a class="btn btn-sm secondary" href="?edit=<?=$r['id']?>" data-testid="edit-<?=$r['id']?>">Düzenle</a>
          <form method="post" style="display:inline" onsubmit="return confirm('Silmek istediğinizden emin misiniz?')"><input type="hidden" name="delete" value="<?=$r['id']?>"><button class="btn btn-sm danger" type="submit" data-testid="delete-<?=$r['id']?>">Sil</button></form>
        </td>
      </tr>
    <?php endforeach; ?>
    </tbody>
  </table>
</div>
<?php include __DIR__.'/_foot.php'; ?>
