<?php
require_once __DIR__ . '/../config.php'; require_admin();
$page_title = 'Mesajlar';
$db = db();
if(!empty($_POST['delete'])){ $db->prepare("DELETE FROM messages WHERE id=?")->execute([(int)$_POST['delete']]); flash('Silindi.'); header('Location: '.base_url('admin/messages.php')); exit; }
if(isset($_GET['read'])){ $db->prepare("UPDATE messages SET is_read=1 WHERE id=?")->execute([(int)$_GET['read']]); header('Location: '.base_url('admin/messages.php')); exit; }
$rows = $db->query("SELECT * FROM messages ORDER BY id DESC")->fetchAll();
include __DIR__.'/_head.php';
?>
<div class="panel">
<h2>Mesajlar</h2>
<table><thead><tr><th>Gönderen</th><th>Konu</th><th>Mesaj</th><th>Durum</th><th>Tarih</th><th></th></tr></thead><tbody>
<?php foreach($rows as $m): ?>
<tr>
<td><strong><?=e($m['name'])?></strong><br><span class="muted small"><?=e($m['email'])?></span></td>
<td><?=e($m['subject'])?></td>
<td style="max-width:400px"><?=nl2br(e($m['body']))?></td>
<td><span class="tag <?=$m['is_read']?'green':'red'?>"><?=$m['is_read']?'Okundu':'Yeni'?></span></td>
<td class="muted small"><?=e($m['created_at'])?></td>
<td><?php if(!$m['is_read']): ?><a class="btn btn-sm secondary" href="?read=<?=$m['id']?>">Okundu</a><?php endif; ?>
<form method="post" style="display:inline" onsubmit="return confirm('Silinsin mi?')"><input type="hidden" name="delete" value="<?=$m['id']?>"><button class="btn btn-sm danger">Sil</button></form></td>
</tr>
<?php endforeach; ?>
<?php if(empty($rows)): ?><tr><td colspan="6" style="text-align:center;color:var(--muted);padding:40px">Henüz mesaj yok.</td></tr><?php endif; ?>
</tbody></table>
</div>
<?php include __DIR__.'/_foot.php'; ?>
