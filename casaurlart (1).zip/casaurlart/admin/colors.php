<?php
require_once __DIR__ . '/../config.php'; require_admin();
$page_title = 'Renk Yönetimi';
$db = db();
if ($_SERVER['REQUEST_METHOD']==='POST') {
    if(!empty($_POST['delete'])){ $db->prepare("DELETE FROM colors WHERE id=?")->execute([(int)$_POST['delete']]); flash('Renk silindi.'); header('Location: '.base_url('admin/colors.php')); exit; }
    $data=[$_POST['name'],$_POST['hex'],(float)$_POST['extra_price']];
    if(!empty($_POST['id'])){ $data[]=(int)$_POST['id']; $db->prepare("UPDATE colors SET name=?,hex=?,extra_price=? WHERE id=?")->execute($data); flash('Renk güncellendi.'); }
    else { $db->prepare("INSERT INTO colors(name,hex,extra_price) VALUES(?,?,?)")->execute($data); flash('Renk eklendi.'); }
    header('Location: '.base_url('admin/colors.php')); exit;
}
$rows = $db->query("SELECT * FROM colors ORDER BY id")->fetchAll();
$edit = null;
if(isset($_GET['edit'])){ $st=$db->prepare("SELECT * FROM colors WHERE id=?"); $st->execute([(int)$_GET['edit']]); $edit=$st->fetch(); }
include __DIR__.'/_head.php';
?>
<div class="panel">
  <h2><?=$edit?'Renk Düzenle':'Yeni Renk Ekle'?></h2>
  <form method="post" data-testid="color-form">
    <?php if($edit): ?><input type="hidden" name="id" value="<?=$edit['id']?>"><?php endif; ?>
    <div class="form-grid">
      <div class="field"><label>Renk Adı</label><input class="input" name="name" required value="<?=e($edit['name']??'')?>" data-testid="c-name"></div>
      <div class="field"><label>HEX Kodu</label><input class="input" name="hex" required value="<?=e($edit['hex']??'#000000')?>" placeholder="#000000"></div>
      <div class="field"><label>Ek Fiyat (<?=e(setting('currency'))?>)</label><input class="input" type="number" step="0.01" name="extra_price" value="<?=e($edit['extra_price']??'0')?>"></div>
    </div>
    <div class="btn-row"><button class="btn" data-testid="c-submit"><?=$edit?'Güncelle':'Ekle'?></button>
    <?php if($edit): ?><a class="btn secondary" href="<?=base_url('admin/colors.php')?>">İptal</a><?php endif; ?></div>
  </form>
</div>
<div class="panel">
  <h2>Renkler</h2>
  <table><thead><tr><th></th><th>Ad</th><th>Hex</th><th>Ek Fiyat</th><th></th></tr></thead><tbody>
  <?php foreach($rows as $r): ?>
    <tr><td><div style="width:42px;height:42px;border-radius:50%;background:<?=e($r['hex'])?>;border:1px solid #ddd"></div></td>
      <td><strong><?=e($r['name'])?></strong></td><td><?=e($r['hex'])?></td><td><?=money($r['extra_price'])?></td>
      <td><a class="btn btn-sm secondary" href="?edit=<?=$r['id']?>">Düzenle</a>
        <form method="post" style="display:inline" onsubmit="return confirm('Silinsin mi?')"><input type="hidden" name="delete" value="<?=$r['id']?>"><button class="btn btn-sm danger">Sil</button></form>
      </td></tr>
  <?php endforeach; ?>
  </tbody></table>
</div>
<?php include __DIR__.'/_foot.php'; ?>
