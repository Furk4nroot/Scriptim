<?php
require_once __DIR__ . '/../config.php'; require_admin();
$page_title = 'Gösterge Paneli';
$db = db();
$products = (int)$db->query("SELECT COUNT(*) FROM products")->fetchColumn();
$orders = (int)$db->query("SELECT COUNT(*) FROM orders")->fetchColumn();
$revenue = (float)$db->query("SELECT COALESCE(SUM(total_price),0) FROM orders")->fetchColumn();
$messages = (int)$db->query("SELECT COUNT(*) FROM messages WHERE is_read=0")->fetchColumn();
$recent = $db->query("SELECT * FROM orders ORDER BY id DESC LIMIT 6")->fetchAll();
include __DIR__ . '/_head.php';
?>
<div class="kpis">
  <div class="kpi" data-testid="kpi-products"><div class="label">Ürünler</div><div class="value"><?=$products?></div></div>
  <div class="kpi" data-testid="kpi-orders"><div class="label">Siparişler</div><div class="value"><?=$orders?></div></div>
  <div class="kpi" data-testid="kpi-revenue"><div class="label">Toplam Ciro</div><div class="value"><?=money($revenue)?></div></div>
  <div class="kpi" data-testid="kpi-messages"><div class="label">Yeni Mesaj</div><div class="value"><?=$messages?></div></div>
</div>
<div class="panel" style="margin-top:24px">
  <h2>Son Siparişler</h2>
  <table><thead><tr><th>#</th><th>Müşteri</th><th>Ürün</th><th>Renk / Model</th><th>Tutar</th><th>Durum</th><th>Tarih</th></tr></thead><tbody>
  <?php foreach($recent as $o): ?>
    <tr><td>#<?=$o['id']?></td><td><?=e($o['customer_name'])?><br><span class="muted small"><?=e($o['customer_phone'])?></span></td>
      <td><?=e($o['product_name'])?></td>
      <td><?=e($o['color'])?> / <?=e($o['model'])?></td>
      <td><strong><?=money($o['total_price'])?></strong></td>
      <td><span class="tag <?=$o['status']==='paid'?'green':''?>"><?=e($o['status'])?></span></td>
      <td class="muted small"><?=e($o['created_at'])?></td></tr>
  <?php endforeach; ?>
  <?php if(empty($recent)): ?><tr><td colspan="7" style="text-align:center;color:var(--muted);padding:40px">Henüz sipariş yok.</td></tr><?php endif; ?>
  </tbody></table>
</div>
<?php include __DIR__ . '/_foot.php'; ?>
