<?php
require_once __DIR__ . '/../config.php'; require_admin();
$page_title = 'Site Ayarları';
$db = db();
if ($_SERVER['REQUEST_METHOD']==='POST') {
    foreach ($_POST as $k => $v) {
        if ($k === 'submit') continue;
        $st = $db->prepare("INSERT INTO settings(key,value) VALUES(?,?) ON CONFLICT(key) DO UPDATE SET value=excluded.value");
        $st->execute([$k, $v]);
    }
    flash('Ayarlar kaydedildi.');
    header('Location: '.base_url('admin/settings.php')); exit;
}
include __DIR__.'/_head.php';
?>
<form method="post" data-testid="settings-form">
<div class="panel">
  <h2>Genel</h2>
  <div class="form-grid">
    <div class="field"><label>Site Adı</label><input class="input" name="site_name" value="<?=e(setting('site_name'))?>" data-testid="s-site-name"></div>
    <div class="field"><label>Para Birimi</label><input class="input" name="currency" value="<?=e(setting('currency'))?>"></div>
    <div class="field full"><label>Slogan / Tagline</label><input class="input" name="site_tagline" value="<?=e(setting('site_tagline'))?>"></div>
    <div class="field full"><label>Hero Başlık</label><input class="input" name="hero_title" value="<?=e(setting('hero_title'))?>"></div>
    <div class="field full"><label>Hero Alt Başlık</label><textarea class="input" name="hero_subtitle" rows="2"><?=e(setting('hero_subtitle'))?></textarea></div>
    <div class="field full"><label>Hakkımızda</label><textarea class="input" name="about" rows="4"><?=e(setting('about'))?></textarea></div>
  </div>
</div>
<div class="panel">
  <h2>Sosyal Medya & İletişim</h2>
  <div class="form-grid">
    <div class="field"><label>WhatsApp Numarası (ülke kodu ile)</label><input class="input" name="whatsapp" value="<?=e(setting('whatsapp'))?>" placeholder="905555555555" data-testid="s-whatsapp"></div>
    <div class="field"><label>Instagram Kullanıcı Adı</label><input class="input" name="instagram" value="<?=e(setting('instagram'))?>" placeholder="casaurlart" data-testid="s-instagram"></div>
    <div class="field"><label>Telefon</label><input class="input" name="phone" value="<?=e(setting('phone'))?>"></div>
    <div class="field"><label>E-posta</label><input class="input" name="email" value="<?=e(setting('email'))?>"></div>
    <div class="field full"><label>Adres</label><input class="input" name="address" value="<?=e(setting('address'))?>"></div>
    <div class="field full"><label>Footer Notu</label><input class="input" name="footer_note" value="<?=e(setting('footer_note'))?>"></div>
  </div>
</div>
<div class="btn-row"><button class="btn" type="submit" data-testid="s-submit">Kaydet</button></div>
</form>
<?php include __DIR__.'/_foot.php'; ?>
