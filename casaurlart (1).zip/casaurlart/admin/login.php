<?php
require_once __DIR__ . '/../config.php';
if (is_admin()) { header('Location: '.base_url('admin/index.php')); exit; }
$err = '';
if ($_SERVER['REQUEST_METHOD']==='POST') {
    $u = trim($_POST['username'] ?? '');
    $p = $_POST['password'] ?? '';
    $st = db()->prepare("SELECT * FROM admins WHERE username=?"); $st->execute([$u]);
    $row = $st->fetch();
    if ($row && password_verify($p, $row['password'])) {
        $_SESSION['admin_id'] = $row['id'];
        $_SESSION['admin_user'] = $row['username'];
        header('Location: '.base_url('admin/index.php')); exit;
    } else { $err = 'Kullanıcı adı veya şifre hatalı.'; }
}
?>
<!doctype html><html lang="tr"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title>Yönetim Girişi · <?=e(setting('site_name'))?></title>
<link href="https://fonts.googleapis.com/css2?family=Fraunces:wght@400;500&family=Manrope:wght@300;400;500;600&display=swap" rel="stylesheet">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.2/css/all.min.css">
<link rel="stylesheet" href="<?=base_url('assets/css/style.css')?>">
</head><body>
<div class="login-shell">
  <form class="login-card" method="post" data-testid="admin-login-form">
    <div style="text-align:center;margin-bottom:20px"><img src="<?=base_url('assets/img/logo.png')?>" style="height:46px;margin:0 auto"></div>
    <h1>Yönetim Paneli</h1>
    <p>casaurlart yöneticisi olarak giriş yap.</p>
    <?php if($err): ?><div class="flash" style="background:#b13a3a;margin-bottom:18px"><?=e($err)?></div><?php endif; ?>
    <div class="field"><label>Kullanıcı Adı</label><input class="input" name="username" required data-testid="login-username" autofocus></div>
    <div class="field" style="margin-top:14px"><label>Şifre</label><input class="input" type="password" name="password" required data-testid="login-password"></div>
    <button class="btn" type="submit" style="width:100%;justify-content:center;margin-top:22px" data-testid="login-submit">Giriş Yap</button>
    <a href="<?=base_url('index.php')?>" class="muted small" style="display:block;text-align:center;margin-top:18px">← Siteye Dön</a>
  </form>
</div></body></html>
