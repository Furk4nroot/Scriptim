<?php
require_once __DIR__ . '/../config.php'; require_admin();
$page_title = 'Kategoriler';
$db = db();
if ($_SERVER['REQUEST_METHOD']==='POST') {
    if(!empty($_POST['delete'])){ $db->prepare("DELETE FROM categories WHERE id=?")->execute([(int)$_POST['delete']]); flash('Kategori silindi.'); header('Location: '.base_url('admin/categories.php')); exit; }
    $name=$_POST['name'];
    $slug=strtolower(preg_replace('/[^a-z0-9]+/i','-',iconv('UTF-8','ASCII//TRANSLIT//IGNORE',$name)));
    if(!empty($_POST['id'])){ $db->prepare("UPDATE categories SET name=?,slug=? WHERE id=?")->execute([$name,$slug,(int)$_POST['id']]); flash('Güncellendi.'); }
    else { $db->prepare("INSERT INTO categories(name,slug) VALUES(?,?)")->execute([$name,$slug]); flash('Eklendi.'); }
    header('Location: '.base_url('admin/categories.php')); exit;
}
$rows = $db->query("SELECT * FROM categories ORDER BY name")->fetchAll();
$edit=null;
if(isset($_GET['edit'])){ $st=$db->prepare("SELECT * FROM categories WHERE id=?"); $st->execute([(int)$_GET['edit']]); $edit=$st->fetch(); }
include __DIR__.'/_head.php';
?>
<div class="panel">
  <h2><?=$edit?'Düzenle':'Yeni Kategori'?></h2>
  <form method="post">
    <?php if($edit): ?><input type="hidden" name="id" value="<?=$edit['id']?>"><?php endif; ?>
    <div class="form-grid">
      <div class="field full"><label>Kategori Adı</label><input class="input" name="name" required value="<?=e($edit['name']??'')?>"></div>
    </div>
    <div class="btn-row"><button class="btn"><?=$edit?'Güncelle':'Ekle'?></button></div>
  </form>
</div>
<div class="panel"><h2>Kategoriler</h2>
<table><thead><tr><th>Ad</th><th>Slug</th><th></th></tr></thead><tbody>
<?php foreach($rows as $r): ?>
<tr><td><?=e($r['name'])?></td><td><?=e($r['slug'])?></td>
<td><a class="btn btn-sm secondary" href="?edit=<?=$r['id']?>">Düzenle</a>
<form method="post" style="display:inline" onsubmit="return confirm('Silinsin mi?')"><input type="hidden" name="delete" value="<?=$r['id']?>"><button class="btn btn-sm danger">Sil</button></form></td></tr>
<?php endforeach; ?>
</tbody></table></div>
<?php include __DIR__.'/_foot.php'; ?>
