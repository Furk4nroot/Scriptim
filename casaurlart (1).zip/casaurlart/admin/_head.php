<?php
// Common admin layout header. Include after require_admin().
$current = basename($_SERVER['PHP_SELF']);
function navlink($file, $label, $icon){
    global $current;
    $cls = $current===$file ? 'active' : '';
    echo '<a class="'.$cls.'" href="'.base_url('admin/'.$file).'" data-testid="nav-'.$file.'"><i class="fa-solid '.$icon.'"></i> '.$label.'</a>';
}
?>
<!doctype html><html lang="tr"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title><?=e($page_title ?? 'Yönetim')?> · <?=e(setting('site_name'))?></title>
<link href="https://fonts.googleapis.com/css2?family=Fraunces:wght@400;500&family=Manrope:wght@300;400;500;600;700&display=swap" rel="stylesheet">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.2/css/all.min.css">
<link rel="stylesheet" href="<?=base_url('assets/css/style.css')?>?v=3">
</head><body>
<div class="admin-shell">
  <aside class="admin-side">
    <div class="brand"><img src="<?=base_url('assets/img/logo.png')?>" style="height:34px"><span class="brand-text"><?=e(setting('site_name'))?></span></div>
    <nav>
      <?php navlink('index.php','Gösterge Paneli','fa-gauge'); ?>
      <?php navlink('products.php','Ürünler','fa-cube'); ?>
      <?php navlink('categories.php','Kategoriler','fa-tags'); ?>
      <?php navlink('colors.php','Renkler','fa-palette'); ?>
      <?php navlink('models.php','Modeller','fa-shapes'); ?>
      <?php navlink('orders.php','Siparişler','fa-receipt'); ?>
      <?php navlink('messages.php','Mesajlar','fa-envelope'); ?>
      <?php navlink('settings.php','Site Ayarları','fa-sliders'); ?>
      <?php navlink('users.php','Yöneticiler','fa-user-shield'); ?>
    </nav>
    <div style="margin-top:30px;padding-top:20px;border-top:1px solid #1f1f1f">
      <a href="<?=base_url('index.php')?>" target="_blank"><i class="fa-solid fa-arrow-up-right-from-square"></i> Siteyi Görüntüle</a>
      <a href="<?=base_url('admin/logout.php')?>" data-testid="admin-logout"><i class="fa-solid fa-right-from-bracket"></i> Çıkış</a>
    </div>
  </aside>
  <main class="admin-main">
    <div class="admin-bar">
      <h1><?=e($page_title ?? '')?></h1>
      <div class="muted">Merhaba, <strong style="color:var(--ink)"><?=e($_SESSION['admin_user'] ?? '')?></strong></div>
    </div>
    <?php if($m=flash()): ?><div class="flash" data-testid="admin-flash"><?=e($m)?></div><?php endif; ?>
