</main>
<footer class="site-footer" id="hakkimizda">
  <div class="container footer-grid">
    <div>
      <div class="brand">
        <img src="<?=base_url('assets/img/logo.png')?>" alt="" onerror="this.style.display='none'">
        <span class="brand-text"><?=e(setting('site_name'))?></span>
      </div>
      <p class="muted"><?=e(setting('about'))?></p>
    </div>
    <div>
      <h4>Keşfet</h4>
      <a href="<?=base_url('products.php')?>">Tüm Koleksiyon</a>
      <a href="<?=base_url('products.php?custom=1')?>">Sana Özel Tasarım</a>
      <a href="<?=base_url('contact.php')?>">İletişim</a>
    </div>
    <div>
      <h4>İletişim</h4>
      <a href="tel:<?=e(setting('phone'))?>"><i class="fa-solid fa-phone"></i> <?=e(setting('phone'))?></a>
      <a href="mailto:<?=e(setting('email'))?>"><i class="fa-solid fa-envelope"></i> <?=e(setting('email'))?></a>
      <span><i class="fa-solid fa-location-dot"></i> <?=e(setting('address'))?></span>
    </div>
    <div>
      <h4>Sosyal</h4>
      <a href="<?=instagram_link()?>" target="_blank" rel="noopener"><i class="fa-brands fa-instagram"></i> @<?=e(setting('instagram'))?></a>
      <a href="<?=whatsapp_link()?>" target="_blank" rel="noopener"><i class="fa-brands fa-whatsapp"></i> WhatsApp</a>
    </div>
  </div>
  <div class="container foot-bottom"><span><?=e(setting('footer_note'))?></span><a href="<?=base_url('admin/login.php')?>" class="muted small">Yönetim</a></div>
</footer>

<a href="<?=whatsapp_link('Merhaba, ürünleriniz hakkında bilgi almak istiyorum.')?>" class="floating-wa" target="_blank" rel="noopener" data-testid="floating-whatsapp" aria-label="WhatsApp">
  <i class="fa-brands fa-whatsapp"></i>
</a>
<a href="<?=instagram_link()?>" class="floating-ig" target="_blank" rel="noopener" data-testid="floating-instagram" aria-label="Instagram">
  <i class="fa-brands fa-instagram"></i>
</a>

<script src="<?=base_url('assets/js/script.js')?>?v=2"></script>
</body></html>
