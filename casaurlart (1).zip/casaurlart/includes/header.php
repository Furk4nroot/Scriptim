<?php require_once __DIR__ . '/../config.php'; ?>
<!doctype html>
<html lang="tr">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title><?=e(setting('site_name'))?> · <?=e($page_title ?? setting('site_tagline'))?></title>
<link rel="icon" type="image/png" href="<?=base_url('assets/img/logo.png')?>">
<link href="https://fonts.googleapis.com/css2?family=Fraunces:opsz,wght@9..144,300;9..144,400;9..144,600;9..144,800&family=Manrope:wght@300;400;500;600;700&display=swap" rel="stylesheet">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.2/css/all.min.css">
<link rel="stylesheet" href="<?=base_url('assets/css/style.css')?>?v=3">
</head>
<body>
<div class="grain"></div>
<header class="site-header" data-testid="site-header">
  <div class="container nav">
    <a href="<?=base_url('index.php')?>" class="brand" data-testid="brand-home-link">
      <img src="<?=base_url('assets/img/logo.png')?>" alt="casaurlart" onerror="this.style.display='none'">
      <span class="brand-text"><?=e(setting('site_name'))?></span>
    </a>
    <nav class="primary-nav">
      <a href="<?=base_url('index.php')?>" data-testid="nav-home">Anasayfa</a>
      <a href="<?=base_url('products.php')?>" data-testid="nav-products">Koleksiyon</a>
      <a href="<?=base_url('products.php?custom=1')?>" data-testid="nav-custom">Sana Özel</a>
      <a href="<?=base_url('index.php#hakkimizda')?>" data-testid="nav-about">Hakkımızda</a>
      <a href="<?=base_url('contact.php')?>" data-testid="nav-contact">İletişim</a>
    </nav>
    <div class="nav-actions">
      <a class="icon-btn" href="<?=instagram_link()?>" target="_blank" rel="noopener" data-testid="nav-instagram"><i class="fa-brands fa-instagram"></i></a>
      <a class="icon-btn whatsapp" href="<?=whatsapp_link('Merhaba, casaurlart ile ilgili bilgi almak istiyorum.')?>" target="_blank" rel="noopener" data-testid="nav-whatsapp"><i class="fa-brands fa-whatsapp"></i></a>
    </div>
    <button class="burger" id="burger" aria-label="menü" data-testid="mobile-burger"><i class="fa-solid fa-bars"></i></button>
  </div>
</header>
<main>
<?php if($m = flash()): ?><div class="container"><div class="flash" data-testid="flash-message"><?=e($m)?></div></div><?php endif; ?>
