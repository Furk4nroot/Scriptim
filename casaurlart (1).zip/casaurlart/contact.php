<?php
require_once __DIR__ . '/config.php';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $st = db()->prepare("INSERT INTO messages(name,email,subject,body) VALUES (?,?,?,?)");
    $st->execute([
        trim($_POST['name'] ?? ''), trim($_POST['email'] ?? ''),
        trim($_POST['subject'] ?? 'İletişim'), trim($_POST['body'] ?? '')
    ]);
    flash('Mesajın bize ulaştı, en kısa sürede dönüş yapacağız.');
    header('Location: '.base_url('contact.php')); exit;
}
$page_title = 'İletişim';
include __DIR__ . '/includes/header.php';
?>
<section class="container contact-grid">
  <div>
    <div class="eyebrow">İletişim</div>
    <h2>Bir fikrin mi var? Konuşalım.</h2>
    <p>Özel tasarım, toplu sipariş veya iş birliği için bize yaz. WhatsApp en hızlı yol.</p>
    <form method="post" style="margin-top:30px" data-testid="contact-form">
      <div class="form-grid">
        <div class="field"><label>Adın</label><input class="input" name="name" required data-testid="contact-name"></div>
        <div class="field"><label>E-posta</label><input class="input" type="email" name="email" required data-testid="contact-email"></div>
        <div class="field full"><label>Konu</label><input class="input" name="subject" data-testid="contact-subject"></div>
        <div class="field full"><label>Mesajın</label><textarea class="input" name="body" rows="5" required data-testid="contact-body"></textarea></div>
      </div>
      <div class="btn-row"><button class="btn" type="submit" data-testid="contact-submit">Gönder</button></div>
    </form>
  </div>
  <aside>
    <div class="panel">
      <h2 style="text-transform:none;letter-spacing:0;font-family:'Fraunces',serif;font-size:1.4rem;font-weight:500;color:var(--ink)">Bize ulaş</h2>
      <p><i class="fa-solid fa-phone"></i> <a href="tel:<?=e(setting('phone'))?>"><?=e(setting('phone'))?></a></p>
      <p><i class="fa-solid fa-envelope"></i> <a href="mailto:<?=e(setting('email'))?>"><?=e(setting('email'))?></a></p>
      <p><i class="fa-solid fa-location-dot"></i> <?=e(setting('address'))?></p>
      <hr style="border:none;border-top:1px solid var(--line);margin:18px 0">
      <a class="btn wa" href="<?=whatsapp_link('Merhaba casaurlart!')?>" target="_blank" style="width:100%;justify-content:center"><i class="fa-brands fa-whatsapp"></i> WhatsApp ile yaz</a>
      <a class="btn outline" href="<?=instagram_link()?>" target="_blank" style="width:100%;justify-content:center;margin-top:8px"><i class="fa-brands fa-instagram"></i> Instagram</a>
    </div>
  </aside>
</section>
<?php include __DIR__ . '/includes/footer.php'; ?>
