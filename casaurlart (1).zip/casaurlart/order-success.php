<?php require_once __DIR__.'/config.php'; $page_title='Teşekkürler'; include __DIR__.'/includes/header.php'; ?>
<section class="container" style="padding:120px 0;text-align:center">
  <i class="fa-solid fa-circle-check" style="font-size:4rem;color:#2e6b2e"></i>
  <h1 style="margin-top:20px">Siparişin alındı!</h1>
  <p>Detaylar için en kısa sürede seninle iletişime geçeceğiz.</p>
  <div class="btn-row" style="justify-content:center">
    <a class="btn" href="<?=base_url('products.php')?>">Alışverişe Devam</a>
    <a class="btn wa" href="<?=whatsapp_link('Merhaba, az önce sipariş verdim.')?>" target="_blank"><i class="fa-brands fa-whatsapp"></i> WhatsApp</a>
  </div>
</section>
<?php include __DIR__.'/includes/footer.php'; ?>
