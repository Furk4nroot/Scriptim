<?php
require_once __DIR__ . '/config.php';
$id = (int)($_GET['id'] ?? 0);
$pst = db()->prepare("SELECT * FROM products WHERE id=?"); $pst->execute([$id]); $p = $pst->fetch();
if (!$p) { header('Location: '.base_url('products.php')); exit; }

if ($_SERVER['REQUEST_METHOD']==='POST') {
    $total = (float)($_POST['total'] ?? $p['price']);
    $st = db()->prepare("INSERT INTO orders
      (customer_name,customer_phone,customer_email,address,product_id,product_name,color,model,custom_logo,custom_notes,total_price,payment_method,status)
      VALUES (?,?,?,?,?,?,?,?,?,?,?,?, 'pending')");
    $st->execute([
        $_POST['name'] ?? '', $_POST['phone'] ?? '', $_POST['email'] ?? '',
        $_POST['address'] ?? '', $p['id'], $p['name'],
        $_POST['color'] ?? '', $_POST['model'] ?? '',
        $_POST['logo'] ?? 'hayır', $_POST['notes'] ?? '',
        $total, $_POST['method'] ?? 'havale'
    ]);
    flash('Siparişin alındı! En kısa sürede dönüş yapacağız.');
    header('Location: '.base_url('order-success.php')); exit;
}

$page_title = 'Ödeme & Sipariş';
include __DIR__ . '/includes/header.php';
?>
<section class="container" style="padding:50px 0">
  <div class="eyebrow">Ödeme</div>
  <h2>Sipariş Bilgileri</h2>
  <form method="post" style="margin-top:30px;display:grid;grid-template-columns:1.2fr .8fr;gap:30px" data-testid="checkout-form">
    <div class="panel">
      <h2>Teslimat</h2>
      <div class="form-grid">
        <div class="field"><label>Ad Soyad</label><input class="input" name="name" required data-testid="co-name"></div>
        <div class="field"><label>Telefon</label><input class="input" name="phone" required data-testid="co-phone"></div>
        <div class="field full"><label>E-posta</label><input class="input" type="email" name="email" required data-testid="co-email"></div>
        <div class="field full"><label>Adres</label><textarea class="input" name="address" rows="3" required data-testid="co-address"></textarea></div>
        <div class="field"><label>Renk</label><input class="input" name="color" data-testid="co-color"></div>
        <div class="field"><label>Model</label><input class="input" name="model" data-testid="co-model"></div>
        <div class="field"><label>Logo Baskı</label>
          <select class="input" name="logo"><option value="hayır">Hayır</option><option value="evet">Evet</option></select>
        </div>
        <div class="field"><label>Ödeme Yöntemi</label>
          <select class="input" name="method" data-testid="co-method">
            <option value="havale">Havale / EFT</option>
            <option value="kapida">Kapıda Ödeme</option>
            <option value="kredi">Kredi Kartı (iletişim ile)</option>
          </select>
        </div>
        <div class="field full"><label>Notlar</label><textarea class="input" name="notes" rows="2"></textarea></div>
      </div>
    </div>
    <aside class="panel">
      <h2>Özet</h2>
      <div style="display:flex;gap:14px;align-items:center;margin-bottom:14px">
        <img src="<?=e(product_image_url($p['image']))?>" style="width:80px;height:80px;border-radius:10px;object-fit:cover">
        <div>
          <strong><?=e($p['name'])?></strong><br>
          <span class="muted small"><?=e($p['material'])?></span>
        </div>
      </div>
      <div style="display:flex;justify-content:space-between;padding:10px 0;border-top:1px solid var(--line)"><span>Tutar</span><strong><?=money($p['price'])?></strong></div>
      <input type="hidden" name="total" value="<?=(float)$p['price']?>">
      <button type="submit" class="btn" style="width:100%;justify-content:center;margin-top:14px" data-testid="co-submit">Siparişi Tamamla</button>
      <p class="muted small" style="margin-top:14px">Siparişin admin paneline düşer, sizinle WhatsApp veya telefonla iletişime geçilir.</p>
    </aside>
  </form>
</section>
<?php include __DIR__ . '/includes/footer.php'; ?>
