<?php
/**
 * casaurlart - Config & DB bootstrap
 * SQLite tabanlı, kurulum gerektirmez. İlk çağrıda tabloları oluşturur ve seed verisini ekler.
 */

session_start();
date_default_timezone_set('Europe/Istanbul');
mb_internal_encoding('UTF-8');

// ---- Paths ----
define('BASE_DIR', __DIR__);
define('DB_PATH', BASE_DIR . '/data/database.sqlite');
define('UPLOAD_DIR', BASE_DIR . '/uploads');

if (!is_dir(BASE_DIR . '/data')) mkdir(BASE_DIR . '/data', 0775, true);
if (!is_dir(UPLOAD_DIR)) mkdir(UPLOAD_DIR, 0775, true);

// ---- Base URL (works in subdir too) ----
function base_url($path = '') {
    // Use root-relative URLs to avoid HTTPS/host proxy issues
    $script = $_SERVER['SCRIPT_NAME'] ?? '';
    $dir = str_replace('\\', '/', dirname($script));
    if (preg_match('#/admin$#', $dir)) $dir = preg_replace('#/admin$#', '', $dir);
    if ($dir === '/' || $dir === '.') $dir = '';
    return $dir . '/' . ltrim($path, '/');
}

// ---- DB ----
function db() {
    static $pdo = null;
    if ($pdo) return $pdo;
    $pdo = new PDO('sqlite:' . DB_PATH);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    $pdo->setAttribute(PDO::ATTR_DEFAULT_FETCH_MODE, PDO::FETCH_ASSOC);
    $pdo->exec('PRAGMA foreign_keys = ON;');
    return $pdo;
}

function setup_db() {
    $db = db();
    $db->exec("CREATE TABLE IF NOT EXISTS settings (
        key TEXT PRIMARY KEY, value TEXT
    )");
    $db->exec("CREATE TABLE IF NOT EXISTS admins (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        username TEXT UNIQUE NOT NULL,
        password TEXT NOT NULL,
        created_at TEXT DEFAULT CURRENT_TIMESTAMP
    )");
    $db->exec("CREATE TABLE IF NOT EXISTS categories (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        name TEXT NOT NULL,
        slug TEXT UNIQUE
    )");
    $db->exec("CREATE TABLE IF NOT EXISTS products (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        name TEXT NOT NULL,
        description TEXT,
        price REAL NOT NULL DEFAULT 0,
        category_id INTEGER,
        image TEXT,
        height TEXT,
        width TEXT,
        depth TEXT,
        weight TEXT,
        material TEXT,
        logo_included INTEGER DEFAULT 0,
        custom_made INTEGER DEFAULT 1,
        custom_extra_price REAL DEFAULT 0,
        stock INTEGER DEFAULT 99,
        is_featured INTEGER DEFAULT 0,
        created_at TEXT DEFAULT CURRENT_TIMESTAMP
    )");
    $db->exec("CREATE TABLE IF NOT EXISTS colors (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        name TEXT NOT NULL,
        hex TEXT NOT NULL,
        extra_price REAL DEFAULT 0
    )");
    $db->exec("CREATE TABLE IF NOT EXISTS models (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        name TEXT NOT NULL,
        extra_price REAL DEFAULT 0
    )");
    $db->exec("CREATE TABLE IF NOT EXISTS orders (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        customer_name TEXT,
        customer_phone TEXT,
        customer_email TEXT,
        address TEXT,
        product_id INTEGER,
        product_name TEXT,
        color TEXT,
        model TEXT,
        custom_logo TEXT,
        custom_notes TEXT,
        total_price REAL,
        payment_method TEXT,
        status TEXT DEFAULT 'pending',
        created_at TEXT DEFAULT CURRENT_TIMESTAMP
    )");
    $db->exec("CREATE TABLE IF NOT EXISTS messages (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        name TEXT, email TEXT, subject TEXT, body TEXT,
        is_read INTEGER DEFAULT 0,
        created_at TEXT DEFAULT CURRENT_TIMESTAMP
    )");

    // Seed defaults if empty
    $cnt = (int)$db->query("SELECT COUNT(*) FROM admins")->fetchColumn();
    if ($cnt === 0) {
        $stmt = $db->prepare("INSERT INTO admins (username, password) VALUES (?, ?)");
        $stmt->execute(['admin', password_hash('Can34', PASSWORD_DEFAULT)]);
        $stmt->execute(['Can34', password_hash('Can34', PASSWORD_DEFAULT)]);
    }

    $defaults = [
        'site_name'      => 'casaurlart',
        'site_tagline'   => '3D Baskı Sanatı · El Yapımı Dekoratif Objeler',
        'hero_title'     => 'El emeği 3D baskı objeler',
        'hero_subtitle'  => 'Renk, model ve boyutu sana özel. Logonu da basalım, eve karakter katsın.',
        'whatsapp'       => '905555555555',
        'instagram'      => 'casaurlart',
        'phone'          => '+90 555 555 55 55',
        'email'          => 'info@casaurlart.com',
        'address'        => 'Türkiye',
        'about'          => 'casaurlart, 3D baskı teknolojisini el işçiliğiyle birleştirerek evine özel objeler üretir. Her parça müşteriye özel ölçü, renk ve modelle hazırlanır.',
        'currency'       => '₺',
        'theme_accent'   => '#0a0a0a',
        'footer_note'    => '© ' . date('Y') . ' casaurlart. Tüm hakları saklıdır.',
    ];
    foreach ($defaults as $k => $v) {
        $st = $db->prepare("INSERT OR IGNORE INTO settings (key, value) VALUES (?, ?)");
        $st->execute([$k, $v]);
    }

    if ((int)$db->query("SELECT COUNT(*) FROM colors")->fetchColumn() === 0) {
        foreach ([
            ['Mat Siyah','#0a0a0a',0],
            ['Krem Beyaz','#f4ebe1',0],
            ['Antrasit Gri','#3a3a3a',25],
            ['Mercan','#e2725b',50],
            ['Zeytin','#5f6b3f',50],
            ['Bakır','#b87333',75],
        ] as $c) {
            $st = $db->prepare("INSERT INTO colors(name,hex,extra_price) VALUES (?,?,?)");
            $st->execute($c);
        }
    }
    if ((int)$db->query("SELECT COUNT(*) FROM models")->fetchColumn() === 0) {
        foreach ([
            ['Standart',0],['Mini',-50],['Maxi',100],['Sınırlı Üretim',250]
        ] as $m) {
            $st = $db->prepare("INSERT INTO models(name,extra_price) VALUES (?,?)");
            $st->execute($m);
        }
    }
    if ((int)$db->query("SELECT COUNT(*) FROM categories")->fetchColumn() === 0) {
        foreach (['Vazolar','Saksılar','Heykeller','Aydınlatma','Aksesuar'] as $c) {
            $slug = strtolower(preg_replace('/[^a-z0-9]+/i','-',iconv('UTF-8','ASCII//TRANSLIT//IGNORE',$c)));
            $st = $db->prepare("INSERT INTO categories(name,slug) VALUES(?,?)");
            $st->execute([$c, $slug]);
        }
    }
    if ((int)$db->query("SELECT COUNT(*) FROM products")->fetchColumn() === 0) {
        $samples = [
            ['Geometrik Vazo','Düşük poly geometrik desenli, mat finish 3D baskı vazo.',490,1,'vazo1.jpg','22 cm','12 cm','12 cm','310 gr','PLA+ Biyo Plastik',1],
            ['Sarmal Saksı','Spiral geometriye sahip iç mekan saksısı, drenajlı.',390,2,'saksi1.jpg','15 cm','14 cm','14 cm','240 gr','PETG',1],
            ['Dalga Heykel','Modern dalga formunda dekoratif heykel.',790,3,'heykel1.jpg','30 cm','18 cm','10 cm','520 gr','Reçine + PLA',0],
            ['Hexa Lamba','Petek desenli, sıcak beyaz LED ile çalışan masa lambası.',1290,4,'lamba1.jpg','25 cm','15 cm','15 cm','480 gr','PLA + LED',1],
            ['Kitap Tutucu','Minimal kitap tutucu, kaymaz tabanlı.',290,5,'destek1.jpg','14 cm','10 cm','8 cm','190 gr','PLA+',0],
            ['Origami Kase','Origami katlama desenli dekoratif kase.',440,5,'kase1.jpg','8 cm','18 cm','18 cm','220 gr','PLA Silk',0],
        ];
        $st = $db->prepare("INSERT INTO products
            (name,description,price,category_id,image,height,width,depth,weight,material,is_featured,custom_made,custom_extra_price)
            VALUES (?,?,?,?,?,?,?,?,?,?,?,1,100)");
        foreach ($samples as $p) $st->execute($p);
    }
}

setup_db();

// ---- Helpers ----
function setting($key, $default = '') {
    static $cache = null;
    if ($cache === null) {
        $cache = [];
        foreach (db()->query("SELECT key,value FROM settings") as $r) $cache[$r['key']] = $r['value'];
    }
    return $cache[$key] ?? $default;
}
function e($s){ return htmlspecialchars((string)$s, ENT_QUOTES, 'UTF-8'); }
function money($n){ return setting('currency','₺') . number_format((float)$n, 2, ',', '.'); }
function flash($msg=null){ if($msg!==null){ $_SESSION['flash']=$msg; return; } $m=$_SESSION['flash']??null; unset($_SESSION['flash']); return $m; }
function is_admin(){ return !empty($_SESSION['admin_id']); }
function require_admin(){ if(!is_admin()){ header('Location: '.base_url('admin/login.php')); exit; } }
function product_image_url($img){
    if (!$img) return 'https://images.unsplash.com/photo-1602810316693-3667c854239a?w=800&q=70';
    if (preg_match('#^https?://#', $img)) return $img;
    $local = UPLOAD_DIR . '/' . $img;
    if (file_exists($local)) return base_url('uploads/' . $img);
    // fallback: unsplash placeholders for seeded products
    $map = [
        'vazo1.jpg'   => 'https://images.unsplash.com/photo-1581783898377-1c85bf937427?w=900&q=70',
        'saksi1.jpg'  => 'https://images.unsplash.com/photo-1485955900006-10f4d324d411?w=900&q=70',
        'heykel1.jpg' => 'https://images.unsplash.com/photo-1554188248-986adbb73be4?w=900&q=70',
        'lamba1.jpg'  => 'https://images.unsplash.com/photo-1507473885765-e6ed057f782c?w=900&q=70',
        'destek1.jpg' => 'https://images.unsplash.com/photo-1519074069444-1ba4fff66d16?w=900&q=70',
        'kase1.jpg'   => 'https://images.unsplash.com/photo-1602874801006-7363f56eb89e?w=900&q=70',
    ];
    return $map[$img] ?? 'https://images.unsplash.com/photo-1602810316693-3667c854239a?w=800&q=70';
}
function whatsapp_link($message=''){
    $num = preg_replace('/\D/','', setting('whatsapp','905555555555'));
    return 'https://wa.me/'.$num.($message?('?text='.rawurlencode($message)):'');
}
function instagram_link(){
    $u = setting('instagram','casaurlart');
    return 'https://instagram.com/'.ltrim($u,'@');
}
