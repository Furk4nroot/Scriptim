<?php
require_once __DIR__ . '/config.php';
$id = (int)($_GET['id'] ?? 0);
$st = db()->prepare("SELECT p.*, c.name as category FROM products p LEFT JOIN categories c ON c.id=p.category_id WHERE p.id=?");
$st->execute([$id]);
$p = $st->fetch();
if (!$p) { header('Location: '.base_url('products.php')); exit; }
$colors = db()->query("SELECT * FROM colors ORDER BY id")->fetchAll();
$models = db()->query("SELECT * FROM models ORDER BY id")->fetchAll();
$page_title = $p['name'];
include __DIR__ . '/includes/header.php';
?>
<section class="container pdp" data-testid="pdp">
  <div class="pdp-gallery">
    <img src="<?=e(product_image_url($p['image']))?>" alt="<?=e($p['name'])?>">
  </div>
  <div>
    <div class="eyebrow"><?=e($p['category'] ?? 'Casaurlart')?></div>
    <h1 data-testid="pdp-title"><?=e($p['name'])?></h1>
    <p><?=nl2br(e($p['description']))?></p>

    <div class="price-row">
      <span class="muted">Toplam</span>
      <span class="total" id="total-price" data-currency="<?=e(setting('currency','₺'))?>"><?=money($p['price'])?></span>
    </div>

    <div class="specs" data-testid="specs">
      <div><span class="label">Boy</span><span><?=e($p['height']?:'—')?></span></div>
      <div><span class="label">En</span><span><?=e($p['width']?:'—')?></span></div>
      <div><span class="label">Genişlik / Derinlik</span><span><?=e($p['depth']?:'—')?></span></div>
      <div><span class="label">Gramaj</span><span><?=e($p['weight']?:'—')?></span></div>
      <div><span class="label">Materyal</span><span><?=e($p['material']?:'—')?></span></div>
      <div><span class="label">Logo Baskı</span><span><?=$p['logo_included']?'Dahil':'Opsiyonel'?></span></div>
    </div>

    <?php if ($p['custom_made']): ?>
    <div class="options-block" data-testid="custom-options">
      <h3>Sana Özel Yap</h3>

      <div class="option-group">
        <label>Renk Seçimi</label>
        <div class="color-swatches">
          <?php foreach($colors as $c): ?>
          <div class="swatch" style="background:<?=e($c['hex'])?>" title="<?=e($c['name'])?> <?=$c['extra_price']>0?'(+'.money($c['extra_price']).')':''?>"
               data-name="<?=e($c['name'])?>" data-extra="<?=(float)$c['extra_price']?>"
               data-testid="color-<?=$c['id']?>" onclick="pickColor(this)"></div>
          <?php endforeach; ?>
        </div>
      </div>

      <div class="option-group">
        <label>Model / Boyut</label>
        <div class="model-chips">
          <?php foreach($models as $m): ?>
          <div class="chip model" data-name="<?=e($m['name'])?>" data-extra="<?=(float)$m['extra_price']?>"
               data-testid="model-<?=$m['id']?>" onclick="pickModel(this)">
            <?=e($m['name'])?> <?=$m['extra_price']!=0?'<small>('.($m['extra_price']>0?'+':'').money($m['extra_price']).')</small>':''?>
          </div>
          <?php endforeach; ?>
        </div>
      </div>

      <div class="option-group">
        <label>Logo Baskısı</label>
        <div class="model-chips">
          <div class="chip logo active" onclick="pickLogo('hayır')">İstemiyorum</div>
          <div class="chip logo" onclick="pickLogo('evet')">Logomu Bas <small>(+<?=money($p['custom_extra_price'])?>)</small></div>
        </div>
      </div>

      <div class="option-group">
        <label>Notlar (özel istek, monogram, ölçü vb.)</label>
        <textarea class="input" id="notes-input" placeholder="Mesajını buraya yaz..."></textarea>
      </div>

      <input type="hidden" id="base-price" value="<?=(float)$p['price']?>">
      <input type="hidden" id="color-input" value="">
      <input type="hidden" id="color-extra" value="0">
      <input type="hidden" id="model-input" value="">
      <input type="hidden" id="model-extra" value="0">
      <input type="hidden" id="logo-input" value="hayır">
      <input type="hidden" id="custom-extra" value="<?=(float)$p['custom_extra_price']?>">
      <input type="hidden" id="product-name" value="<?=e($p['name'])?>">

      <div class="btn-row">
        <a id="order-wa" class="btn wa" data-base="<?=e(whatsapp_link(''))?>" href="#" target="_blank" rel="noopener" data-testid="pdp-order-whatsapp"><i class="fa-brands fa-whatsapp"></i> WhatsApp ile Sipariş Ver</a>
        <a href="<?=base_url('checkout.php?id='.$p['id'])?>" class="btn outline" data-testid="pdp-checkout">Ödeme Sayfası</a>
      </div>
    </div>
    <?php else: ?>
      <div class="btn-row">
        <a class="btn wa" href="<?=whatsapp_link('Merhaba, '.$p['name'].' satın almak istiyorum.')?>" target="_blank"><i class="fa-brands fa-whatsapp"></i> WhatsApp ile Sipariş Ver</a>
      </div>
    <?php endif; ?>
  </div>
</section>
<?php include __DIR__ . '/includes/footer.php'; ?>
