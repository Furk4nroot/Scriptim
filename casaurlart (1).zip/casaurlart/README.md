# casaurlart — 3D Print E-Commerce (PHP)

Modern bir 3D baskı / dekoratif obje e-ticaret sitesi. Tek dosyalık PHP kurulumu, SQLite veritabanı, admin paneli, custom-made ürün özelleştirme, WhatsApp / Instagram entegrasyonu.

## Özellikler
- **Modern UI**: Fraunces serif + Manrope sans, krem-siyah palette, grain doku, micro-animasyonlar
- **Admin Panel**: Ürün/Kategori/Renk/Model/Yönetici/Ayar yönetimi, sipariş takibi, mesaj kutusu
- **Custom Made**: Müşteri renk, model ve logo seçer; her seçim fiyatı canlı olarak günceller
- **Specler**: Boy / En / Genişlik / Gramaj / Materyal + Logo (admin'den girilir)
- **WhatsApp & Instagram**: Tüm butonlar admin paneldan ayarlanır, sayfada floating + header
- **Sipariş Sistemi**: WhatsApp ile sipariş + Sepet/Form ile sipariş + Ödeme yöntemi seçimi
- **SQLite**: Kurulum gerekmez, ilk açılışta otomatik schema + seed
- **Türkçe**

## Hızlı Başlangıç (Local)
PHP 8.0+ gerekir.
```bash
cd casaurlart
php -S 0.0.0.0:8000
```
Tarayıcıdan: `http://localhost:8000`

## Hosting (cPanel / Shared)
1. Tüm dosyaları `public_html`'e at.
2. `data/` ve `uploads/` klasörlerine yazma izni ver (chmod 775).
3. Site çalışmaya hazır. Admin: `/admin/login.php`

## Varsayılan Girişler
- **admin** / `Can34`
- **Can34** / `Can34`

Admin > Yöneticiler bölümünden şifre değiştirebilir, yeni admin ekleyebilirsin.

## Klasör Yapısı
```
casaurlart/
├── config.php          # DB + helper + auto setup
├── index.php           # Anasayfa
├── products.php        # Koleksiyon
├── product.php         # Ürün detay + custom-made
├── checkout.php        # Ödeme formu
├── contact.php         # İletişim
├── admin/              # Yönetim paneli
├── includes/           # Header/footer parçaları
├── assets/             # CSS / JS / Logo
├── data/database.sqlite
└── uploads/            # Yüklenen ürün görselleri
```

## Önemli Notlar
- WhatsApp numarasını **ülke kodu ile başlatın** (örn: 905555555555).
- Instagram için sadece kullanıcı adı yeterli (`casaurlart`), URL otomatik oluşur.
- Ürün eklerken görsel zorunlu değil; eklenmezse placeholder kullanılır.

© casaurlart
