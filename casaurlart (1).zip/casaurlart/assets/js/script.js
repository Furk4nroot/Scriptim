// Mobile burger
const burger = document.getElementById('burger');
if (burger) {
  burger.addEventListener('click', () => {
    document.querySelector('.primary-nav')?.classList.toggle('open');
  });
}

// Custom-made price recompute
function pickColor(el){
  document.querySelectorAll('.swatch').forEach(s=>s.classList.remove('active'));
  el.classList.add('active');
  document.getElementById('color-input').value = el.dataset.name;
  document.getElementById('color-extra').value = el.dataset.extra;
  recompute();
}
function pickModel(el){
  document.querySelectorAll('.chip.model').forEach(s=>s.classList.remove('active'));
  el.classList.add('active');
  document.getElementById('model-input').value = el.dataset.name;
  document.getElementById('model-extra').value = el.dataset.extra;
  recompute();
}
function pickLogo(v){
  document.querySelectorAll('.chip.logo').forEach(s=>s.classList.remove('active'));
  event.target.classList.add('active');
  document.getElementById('logo-input').value = v;
  recompute();
}
function recompute(){
  const base = parseFloat(document.getElementById('base-price')?.value||0);
  const colorEx = parseFloat(document.getElementById('color-extra')?.value||0);
  const modelEx = parseFloat(document.getElementById('model-extra')?.value||0);
  const customEx = parseFloat(document.getElementById('custom-extra')?.value||0);
  const isCustom = (document.getElementById('color-input')?.value !== '' || document.getElementById('model-input')?.value !== '' || document.getElementById('logo-input')?.value === 'evet');
  const total = base + colorEx + modelEx + (isCustom?customEx:0);
  const el = document.getElementById('total-price');
  if (el){
    const cur = el.dataset.currency || '₺';
    el.textContent = cur + total.toLocaleString('tr-TR',{minimumFractionDigits:2, maximumFractionDigits:2});
  }
  const waLink = document.getElementById('order-wa');
  if (waLink){
    const name = document.getElementById('product-name')?.value;
    const color = document.getElementById('color-input')?.value || '—';
    const model = document.getElementById('model-input')?.value || '—';
    const logo = document.getElementById('logo-input')?.value || 'hayır';
    const notes = document.getElementById('notes-input')?.value || '';
    const msg = `Merhaba casaurlart, sipariş vermek istiyorum:%0A• Ürün: ${name}%0A• Renk: ${color}%0A• Model: ${model}%0A• Logo: ${logo}%0A• Not: ${notes}%0A• Toplam: ${total.toFixed(2)} ₺`;
    waLink.href = waLink.dataset.base + '?text=' + msg;
  }
}
document.addEventListener('DOMContentLoaded', () => {
  recompute();
  document.getElementById('notes-input')?.addEventListener('input', recompute);
});

// Fade-in observer
const io = new IntersectionObserver((entries) => {
  entries.forEach(e => {
    if (e.isIntersecting) { e.target.style.opacity = 1; e.target.style.transform = 'translateY(0)'; }
  });
}, {threshold:0.08});
document.querySelectorAll('.card, .feature, .hero-art, .section-head').forEach(el => {
  el.style.opacity = 0; el.style.transform = 'translateY(20px)';
  el.style.transition = 'opacity .8s ease, transform .8s ease';
  io.observe(el);
});
